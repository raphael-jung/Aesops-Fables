# -*- coding: utf-8 -*-
from tika import parser # pip install tika
import unidecode
import ebooklib
from ebooklib import epub
from bs4 import BeautifulSoup
import spacy
from PyPDF2 import PdfReader
from utils import *

# load spacy model
spacy_model = spacy.load('en_core_web_sm')
spacy_model.max_length = 3000000 

class fileparser:
    def init(self, path: str):
        self.path    = path
        self.fname   = os.path.basename(path) 
        self.id   = os.path.splitext(self.fname)[0] # get fname without extension
        # self.category= path.split("\\")[1]

    def parse(self, raw):
        # build model
        doc = spacy_model(raw)
        # Tokenize and lemmatize
        # Remove any words that is either stopwords, punctuations, or numbers.
        self.text_token = [token.lemma_ for token in doc if not token.is_stop and not token.is_punct and not token.like_num and not token.is_space]
        self.sent_token = [[token.lemma_ for token in sent if not token.is_stop and not token.is_punct and not token.like_num and not token.is_space] for sent in doc.sents]

        
    def save(self):
        with open(self.path+'.pickle', 'wb') as file:
            pickle.dump(self, file)

    def load(self, path):
        with open(path+'.pickle', 'rb') as file:
            loaded      = pickle.load(file)
            for v in vars(loaded):
                exec(f"self.{v} = loaded.{v}")

class pdfparser(fileparser):
    def __init__(self, path):
        if os.path.isfile(path+'.pickle'):
            # if already pickled, load it
            self.load(path)
        else:
            self.init(path) # store basic info
            raw = self.read() # read text
            self.parse(raw) # parse into raw/sent
            self.save() # save to pickle

    def read(self):
        """
        If there are docs with spaced words, then use tika (less spaced w o r d s)
        pdf1 = PdfReader(open(self.path, 'rb'))
        text = ""
        for page in pdf1.pages:
            text += page.extract_text() + "\n"
        text = text.lower()
        return text # return text from pypdf2

        otherwise, just use parser.
        """
        # No unicode decode done for pdf
        return parser.from_file(self.path)['content'].lower() # read file text using TIKA

class epubparser(fileparser):
    def __init__(self, path):
        if os.path.isfile(path+'.pickle'):
            # if already pickled, load it
            self.load(path)
        else:
            self.init(path) # store basic info
            raw = self.read() # read text
            self.parse(raw) # parse into raw/sent
            self.save() # save to pickle

    def read(self):
        blacklist = ['[document]', 'noscript', 'header', 'html', 'meta', 'head', 'input', 'script', 'style', 'a'] # set up blacklist tags
        book = epub.read_epub(self.path) # first, read a book

        output = ''
        for doc in book.get_items_of_type(ebooklib.ITEM_DOCUMENT):
            soup = BeautifulSoup(doc.get_content(), "html.parser")
            for text_object in soup.find_all(text=True):
                if text_object.parent.name not in blacklist:
                    output += '{} '.format(text_object)

        return unidecode.unidecode(output).lower() # deal with encoding issues

def read_pdf():
    for path in paths_pdf:
        p = pdfparser(path)
        print('PDF:', p.id, len(p.text_token), len(p.sent_token))

def read_epub():
    for path in paths_epub:
        p = epubparser(path)
        print('EPUB:', p.id, len(p.text_token), len(p.sent_token))



if __name__ == '__main__':

    # read_pdf()
    # read_epub()
    # pass

    docs = get_docs()
    for d in docs:
        print(len(d.text_token), len(d.sent_token))
