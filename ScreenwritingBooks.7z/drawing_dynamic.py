# -*- coding: utf-8 -*-
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import os
os.environ["MKL_NUM_THREADS"] = "1" 
os.environ["NUMEXPR_NUM_THREADS"] = "1" 
os.environ["OMP_NUM_THREADS"] = "1" 
from collections import Counter
import numpy as np
import matplotlib.pyplot as plt
from utils import *

def plot_embeddings(embedding, id, xmin, xmax, ymin, ymax):
    x = embedding[:, 0]
    y = embedding[:, 1]
    plt.plot(x, y, '.', alpha=0.4)
    plt.title(id)
    plt.xlim(xmin, xmax)
    plt.ylim(ymin, ymax)
    plt.savefig(DATAFOLDER + f'dynamic_perdoc/{id}.png')
    plt.close()


# # Read tf-idf, transpose it to show WORDS as nodes
# df = pd.read_csv(DATAFOLDER + 'tf-idf.csv').set_index('id').drop(['category'], axis=1)

years = pd.read_excel(open(DATAFOLDER + 'Doc Info.xlsx', 'rb'), sheet_name='Sheet1')[['id', 'pub_year']]

# Read tf-idf, DON't transpose it to show DOCS as nodes
dflist = [
    (
        'tf-idf',
        pd.read_csv(DATAFOLDER + 'Models/tf-idf.csv').merge(years, on='id')
    ),
    (
        'lda',
        pd.read_csv(DATAFOLDER + 'Models/lda_docvectors.csv').merge(years, on='id')
    ),
    (
        'w2v',
        pd.read_csv(DATAFOLDER + 'Models/w2v_docvectors.csv').merge(years, on='id')
    )
]


out = []
for embname, df in dflist:
    print(embname)

    df_embedding = df.copy()
    if 'id' in df.columns:
        df_embedding = df_embedding.drop(['id'], axis=1)
    if 'pub_year' in df.columns:
        df_embedding = df_embedding.drop(['pub_year'], axis=1)

    for algname, alg in [('pca',PCA(n_components=2)), ('tsne', TSNE(n_components=2))]:
        # Get embedding positions
        embedding = alg.fit_transform(df_embedding.values)

        # Then record them with year information
        o = [(df.iloc[i].id, df.iloc[i].pub_year, x, y) for i,(x,y) in enumerate(embedding)]
        df_out = pd.DataFrame(o, columns=['id', 'year', 'x', 'y'])
        # xmin = min(df_out['x'].values.tolist())
        # xmax = max(df_out['x'].values.tolist())
        # ymin = min(df_out['y'].values.tolist())
        # ymax = max(df_out['y'].values.tolist())
        for y, group in df_out.groupby('year'):
            # make graph for each year
            # e = np.array(group[['x','y']].values.tolist())
            # plot_embeddings(e, f"{embname}_{algname}_{y}", xmin, xmax, ymin, ymax)
            
            # just record it in csv instead, averaging the vectors
            e_avg = group[['x','y']].mean().values.tolist()
            out.append([embname, algname, y] + e_avg)

pd.DataFrame(out).to_csv(DATAFOLDER + 'embedding_per_year.csv', index=False)