# -*- coding: utf-8 -*-
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import os
os.environ["MKL_NUM_THREADS"] = "1" 
os.environ["NUMEXPR_NUM_THREADS"] = "1" 
os.environ["OMP_NUM_THREADS"] = "1" 
from collections import Counter
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from utils import *
from sklearn.cluster import AgglomerativeClustering

dflist = [
    ('tf_idf', pd.read_csv(DATAFOLDER + 'Models/tf-idf.csv')),
    ('lda', pd.read_csv(DATAFOLDER + 'Models/lda_docvectors.csv'))
    # ('w2v', pd.read_csv(DATAFOLDER + 'Models/w2v_docvectors.csv'))
    # w2v is not used in 4.1 because each word is already a vector
]

n_top_words = 21
out = []
out2 = []


for tm, df in dflist:
    for perc in np.concatenate([np.arange(0.01,0.1,0.01), np.arange(0.1,1.0,0.1), np.arange(0.91,1.0,0.01), np.arange(1.0,5.0,0.1)]):
        vec = df.drop(['id'], axis=1)
        vectors = vec.values # find document groups
        
        vecmax = vectors.max()
        agglomerative = AgglomerativeClustering(n_clusters=None, distance_threshold= perc).fit(vectors)
        
        print(tm, perc, len(np.unique(agglomerative.labels_)))
#         out.extend([(tm, perc, d, c) for d,c in enumerate(agglomerative.labels_)])

#         print(tm, perc, len(np.unique(agglomerative.labels_)))
#         # Also get top words
#         # get_top_features_cluster(tf_idf_array, prediction, n_feats):
#         # https://stackoverflow.com/questions/73556514/how-to-extract-top-words-from-k-means-clusters-using-scikit
#         vec_temp = vec.copy()
#         vec_temp.insert(0,'cluster', agglomerative.labels_)
#         x_means = vec_temp.groupby(['cluster']).mean().T
#         for c in np.unique(agglomerative.labels_):
#             topn = x_means.nlargest(n_top_words, [c])[c]
#             out2.extend((tm, perc, c, i, w, v) for i,(w,v) in enumerate(zip(topn.index.tolist(), topn.tolist())))

# pd.DataFrame(out, columns=['Topic model', 'Distance Threshold', 'Document Id', 'Cluster Id']).to_csv(DATAFOLDER + 'agglomerative.csv', index=False)
# pd.DataFrame(out2, columns=['Topic model', 'Distance Threshold', 'Cluster Id', 'Rank', 'Word', 'Feature importance']).to_csv(DATAFOLDER + 'agglomerative_feature_importance.csv', index=False)
