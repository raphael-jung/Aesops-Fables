from utils import *
from document import *
import gensim
import pandas as pd
import numpy as np
from nltk.sentiment.vader import SentimentIntensityAnalyzer

from sklearn.cluster import KMeans

def cluster_with_seed_words():
    seed_words = [
        ['structure', 'story', 'plot', 'conflict', 'character', 'genre', 'theme', 'motif', 'action'],
        ['dialogue', 'format', 'film', 'camera', 'pov', 'movie', 'screen', 'video', 'sound', 'edit'],
        ['audience', 'reader', 'fan', 'involve', 'empathy', 'emotion', 'response'],
        ['industry', 'business', 'market', 'budget', 'studio', 'production', 'producer']
    ]
    model = gensim.models.Word2Vec.load(DATAFOLDER + f'Models/SM.word2vec')
    centroids = [np.average([model.wv[w] for w in words], axis=0) for words in seed_words]
    words = list(model.wv.index_to_key)

    wordvec = np.array([model.wv[w] for w in words])

    # cluster them into two
    model = KMeans(len(seed_words), n_init='auto', init=centroids)
    model.fit(wordvec)
    labels = model.predict(wordvec)

    df = pd.DataFrame(zip(words, labels), columns=['Word', 'Cluster'])
    df.to_csv(DATAFOLDER + f"story_vs_movie_vs_audience_vs_industry.csv", index=False)

def opposition():
    opposite_words = [
        ('Narrative', ['story', 'theme', 'content', 'structure', 'plot', 'form']),
        ('Story', ['character', 'persona', 'ego', 'protagonist', 'antagonist', 'hero', 'plot', 'structure', 'sequence', 'point', 'turning']),
        ('Character', ['persona', 'ego', 'psychology', 'role', 'protagonist', 'antagonist', 'hero', 'heroine'])
    ]
    
    model = gensim.models.Word2Vec.load(DATAFOLDER + f'Models/SM.word2vec')

    for t, l in opposite_words:
        print(t)
        out = []
        for i in l:
            o = []
            for j in l:
                o.append(model.wv.similarity(i,j))
            out.append(o)
        print(pd.DataFrame(out))

    

# 4.1. Definition - define things like screenwriter/audience/industry by similar_by_word()
def define(categories, topn=20):    
    out = []
    # All 'whole' model's definition
    model = gensim.models.Word2Vec.load(DATAFOLDER + f'Models/SM.word2vec')
    for cat in categories:
        sim_words = model.wv.similar_by_word(cat, topn)
        out.extend([['Whole', cat, i] + list(tup) for i, tup in enumerate(sim_words)])

    # Per document definition
    for f in paths_w2v:
        name = os.path.basename(f).replace(".word2vec","") 
        model = gensim.models.Word2Vec.load(f)
        for cat in categories:
            if cat in model.wv.key_to_index:
                sim_words = model.wv.similar_by_word(cat, topn)
                out.extend([[name, cat, i] + list(tup) for i, tup in enumerate(sim_words)])
    
    # save output
    df = pd.DataFrame(out, columns=['DocId', 'Category', 'Rank', 'Word', 'Similarity'])
    df.to_csv(DATAFOLDER + 'define_categories.csv', index=False)

def get_w2c_centroid():
    for f in paths_w2v:
        name = os.path.basename(f).replace(".word2vec","") 
        model = gensim.models.Word2Vec.load(f)
        centroid = np.average([model.wv[w] for w in model.wv.key_to_index], axis=0)
        centroid_word = model.wv.similar_by_vector(centroid, 1)[0][0]
        print(name, centroid_word)

def print_overlap(topn=20):
    df = pd.read_csv(DATAFOLDER + 'define_categories.csv')
    for d, dfd in df.groupby(['DocId']):

        s = set(dfd.loc[dfd['Category'] == "screenwriter"]['Word'].values.tolist())
        a = set(dfd.loc[dfd['Category'] == "audience"]['Word'].values.tolist())
        i = set(dfd.loc[dfd['Category'] == "industry"]['Word'].values.tolist())

        sa = len(s & a)
        ai = len(a & i)
        si = len(s & i)
        sai = len(s & i & a)
        print(d, sa, ai, si, sai)


def sentiment():
    analyzer = SentimentIntensityAnalyzer()
    # create get_sentiment function

    def get_sentiment(s):
        scores = analyzer.polarity_scores(s['text'])
        # sentiment = 1 if scores['pos'] > 0 else 0
        s['neg'] = scores['neg']
        s['neu'] = scores['neu']
        s['pos'] = scores['pos']
        s['compound'] = scores['compound']
        return s


    df = pd.DataFrame([[d.id, ' '.join(d.text_token)] for d in get_docs()], columns=['id', 'text'])
    # print(docs)
    
    df = df.apply(get_sentiment, axis=1)

    # print(df[['id','sentiment']])
    df[['id','neg', 'neu', 'pos', 'compound']].to_csv(DATAFOLDER + 'sentiment.csv', index=False)

    # return df


# 4.2. Division - thing like 
#         narrative theory (character, plot, structure, suspense) + film theory (audiovisual, multimedia),+ industry (business, budget, salary, pitching, advertisement, marketing, communication)
#         normative - creative
#         their "precarious" SUM = screenwriting/writer etc?
#         - cluster them
#         - or compare vector between screenwriting vs wordnet's narrative,creative, normative etc.
words_narrative = ["narrative", "character", "plot", "structure", "suspense"]
words_film      = ["film", "audio", "visual", "multi"]
words_industry  = ["industry", "business", "budget", "pitching", "advertise", "marketing", "communication"]

words_precarious = ["norma", "creative"]




# run clustering
def cluster(n=5):
    model = gensim.models.Word2Vec.load(DATAFOLDER + f'Models/SM.word2vec')
    words = list(model.wv.index_to_key)
    embeddings = np.array([model.wv[w] for w in words])
    labels = kmeans(embeddings,num_topics=n)
    df = pd.DataFrame(zip(words, labels), columns=['Word', 'Cluster'])

    c = df.groupby(['Cluster'])['Cluster'].count()
    print(c)

    print("Narrative:")
    for w in words_narrative:
        if w in df['Word'].values:
            print(w, df.loc[df['Word']==w]['Cluster'].values[0])

    print("Film:")
    for w in words_film:
        if w in df['Word'].values:
            print(w, df.loc[df['Word']==w]['Cluster'].values[0])

    print("Industry:")
    for w in words_industry:
        if w in df['Word'].values:
            print(w, df.loc[df['Word']==w]['Cluster'].values[0])

    print("Precarious:")
    for w in words_precarious:
        if w in df['Word'].values:
            print(w, df.loc[df['Word']==w]['Cluster'].values[0])

    # df.to_csv(DATAFOLDER + f"kmeans_{n}.csv", index=False)
    


def find_similar_words():
    topn = 20
    seed_words = [
        "antagonist", "audience", "character", "consumer", "content", "creativity", "ego", "form", "hero", "heroine", 
        "persona", "plot", "point", "protagonist", "psychology", "reader", "role", "screenplay", "screenwriter", 
        "screenwriting", "script", "sequence", "spectator", "story", "structure", "theme", "turning",
        "movie", "business", "film", "money", "production",
        'know', 'like', 'write', 'scene'
    ]
    sims = []

    # all
    print('all')
    model = gensim.models.Word2Vec.load(DATAFOLDER + f'Models/SM.word2vec')
    words = [w for w in seed_words if w in model.wv.key_to_index]
    sims.extend([('all', w, i+1, w2, v) for w in words for i, (w2,v) in enumerate(model.wv.most_similar(positive=[w], topn=topn))])

    print(model.wv.most_similar(positive=['turning'], topn=topn))
    # per_doc
    for f in [f for f in glob.glob(DATAFOLDER + f'Models/w2v/*.word2vec')]:
        id = os.path.splitext(os.path.basename(f))[0]
        print(id)
        with open(f, 'rb') as file:
            model = gensim.models.Word2Vec.load(f)
            words = [w for w in seed_words if w in model.wv.key_to_index]
            sims.extend([(f'Doc_{id}', w, i+1, w2, v) for w in words for i, (w2,v) in enumerate(model.wv.most_similar(positive=[w], topn=topn))])
        
    # per_year
    for f in [f for f in glob.glob(DATAFOLDER + f'Models/w2v_year/*.word2vec')]:
        id = os.path.splitext(os.path.basename(f))[0]
        print(id)
        with open(f, 'rb') as file:
            model = gensim.models.Word2Vec.load(f)
            words = [w for w in seed_words if w in model.wv.key_to_index]
            sims.extend([(f'Year_{id}', w, i+1, w2, v) for w in words for i, (w2,v) in enumerate(model.wv.most_similar(positive=[w], topn=topn))])

    df = pd.DataFrame(sims, columns=['Type', 'Keyword', 'Rank', 'Similar Word', 'Val'])
    df.to_csv(DATAFOLDER + f"sim_words.csv", index=False)


if __name__ == '__main__':
    # prob3_categories = ['screenwriter', 'creativity', 'audience', 'screenplay', 'script', 'reader', 'spectator', 'consumer']
    # define(prob3_categories)
    
    # sentiment()

    # cluster_with_seed_words()

    # opposition()
    find_similar_words()
    # pass