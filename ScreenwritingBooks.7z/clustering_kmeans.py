# -*- coding: utf-8 -*-
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import os
os.environ["MKL_NUM_THREADS"] = "1" 
os.environ["NUMEXPR_NUM_THREADS"] = "1" 
os.environ["OMP_NUM_THREADS"] = "1" 
from collections import Counter
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from utils import *

def predict_topics_with_kmeans(embeddings,num_topics):
    kmeans_model = KMeans(num_topics, n_init='auto')
    kmeans_model.fit(embeddings)
    topics_labels = kmeans_model.predict(embeddings)
    return kmeans_model, topics_labels


dflist = [
    ('tf_idf', pd.read_csv(DATAFOLDER + 'Models/tf-idf.csv')),
    ('lda', pd.read_csv(DATAFOLDER + 'Models/lda_docvectors.csv'))
    # ('w2v', pd.read_csv(DATAFOLDER + 'Models/w2v_docvectors.csv'))
    # w2v is not used in 4.1 because each word is already a vector
]

n_top_words = 20
out = []
out2 = []
for tm, df in dflist:
    vec = df.drop(['id'], axis=1)
    
    for num_topics in [10,8,6,4,3,2]:
        vectors = vec.values # find document groups
        kmeans_model, kmean_clusterids = predict_topics_with_kmeans(vectors, num_topics)

        # Add cluster ids to the df file
        df.insert(1, f"{num_topics} clusters", kmean_clusterids)


        # then calculate feature importance for this df/ntopic combo.
        # copy from https://towardsdatascience.com/interpretable-k-means-clusters-feature-importances-7e516eeb8d3c#7e14
        # higher value = higher impact on WCSS minimization.
        centroids = kmeans_model.cluster_centers_
        sorted_centroid_features_idx = centroids.argsort(axis=1)[:,::-1]
        sorted_centroid_features_values = np.take_along_axis(centroids, sorted_centroid_features_idx, axis=1)
        for c in range(num_topics):
            centroid = centroids[c][sorted_centroid_features_idx[c]]
            feature_importance = list(
                zip(
                    [vec.columns[feature] for feature in sorted_centroid_features_idx[c]], 
                    centroid
                )
            )[:n_top_words]
            feature_importance = [(tm, num_topics, c, i, w, v) for i,(w,v) in enumerate(feature_importance)]
            out.extend(feature_importance)

        # Also get top words
        # get_top_features_cluster(tf_idf_array, prediction, n_feats):
        # https://stackoverflow.com/questions/73556514/how-to-extract-top-words-from-k-means-clusters-using-scikit
        
        vec_temp = vec.copy()
        vec_temp.insert(0,'cluster', kmean_clusterids)
        x_means = vec_temp.groupby(['cluster']).mean().T
        for c in range(num_topics):
            topn = x_means.nlargest(n_top_words, [c])[c]
            out2.extend((tm, num_topics, c, i, w, v) for i,(w,v) in enumerate(zip(topn.index.tolist(), topn.tolist())))

    # save kmean cluster results with vectors
    df.to_csv(DATAFOLDER + f'/kmeans_for_docs_{tm}.csv', index=False)
pd.DataFrame(out, columns=['Topic model', 'Number of clusters', 'Cluster Id', 'Rank', 'Word', 'Feature importance']).to_csv(DATAFOLDER + 'kmeans_for_docs_feature_importance.csv', index=False)
pd.DataFrame(out2,columns = ['Topic model', 'Number of clusters', 'Cluster Id', 'Rank', 'Word', 'score']).to_csv(DATAFOLDER + 'kmeans_for_docs_top_avg_score.csv', index=False)
            