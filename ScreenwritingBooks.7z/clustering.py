# -*- coding: utf-8 -*-
import pandas as pd
from sklearn.cluster import KMeans
import os
os.environ["MKL_NUM_THREADS"] = "1" 
os.environ["NUMEXPR_NUM_THREADS"] = "1" 
os.environ["OMP_NUM_THREADS"] = "1" 
from gensim.corpora import Dictionary
import numpy as np
from utils import *


def kmeans_differinttopics(df,prefix):
  embedding = df.drop(['id'], axis=1).values
  df = df[['id']].copy()
  for i in [2,3,5,10]:
    # run clustering
    label_kmeans = kmeans(embedding,num_topics=i)

    # merge ids and cluster ids
    df[f"{i} clusters"] = label_kmeans

  df.to_csv(f'./{prefix}_kmeans.csv', index=False)




def save_lda_docvectors():
  df_topic = pd.read_excel(open(DATAFOLDER + 'Models/lda.xlsx', 'rb'), sheet_name='Topics')
  df_dist  = pd.read_excel(open(DATAFOLDER + 'Models/lda.xlsx', 'rb'), sheet_name='Distributions')

  # First get unique tokens
  wordbag = [[str(i) for i in list(df_topic['word'])]]
  tokens = Dictionary(wordbag)

  nrows = len(df_topic['topicId'].unique()) # number of topics
  ncols = len(tokens) # number of unique words
  # build embedding
  embedding = np.zeros((nrows,ncols))
  for _, row in df_topic.iterrows():
      i = row['topicId']
      j = tokens.token2id[str(row['word'])]
      embedding[i][j] += row['weight']

  # Loop through each id
  out = []
  for id, group in df_dist.groupby('id'):    
      # extract sum of topic vectors, and sum it up to build a vector
      vec = (embedding[group['topicId']] * np.array(group['distribution'])[:,np.newaxis]).sum(axis=0)
      row = [id]
      row.extend(vec.flatten())
      out.append(row)
      # print(row)
  df = pd.DataFrame(out, columns = ['id'] + [tokens[i] for i in range(len(tokens))])
  df.to_csv(DATAFOLDER + 'Models/lda_docvectors.csv', index=False)

save_lda_docvectors()
# df_topic = pd.read_excel(open('lda.xlsx', 'rb'), sheet_name='Topics')
# print(df_topic)

# read file
# df = pd.read_csv(DATAFOLDER + 'lda_docvectors_1242.csv')
# kmeans_differinttopics(df, 'lda')