# -*- coding: utf-8 -*-
from utils import *
import gensim
import pandas as pd
import numpy as np
import itertools
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity

def get_w2v_docvectors(foldername="Models/w2c"):
    out = []
    for f in paths_w2v:
        dname = os.path.basename(f).replace(".word2vec","") 

        w2v = gensim.models.Word2Vec.load(f)
        words = list(w2v.wv.key_to_index)
        avg_vec = list(np.mean(w2v.wv[words], axis=0))

        out.append([dname] + avg_vec)

    pd.DataFrame(out).to_csv(DATAFOLDER + 'Models/w2v_docvectors.csv', index=False)


get_w2v_docvectors()

def compair_top_pairs():
    n_order = 5
    words_comb = list(itertools.combinations(TARGET_WORDS, 2))

    out = []
        
    model = gensim.models.Word2Vec.load(DATAFOLDER + f'Models/SM.word2vec')

    for w in TARGET_WORDS:
        if w not in model.wv.key_to_index:
            print(f"{w} not in model.")

    # loop each combination
    for i,j in words_comb:
        # Run only when a set vocab is in the model
        if i in model.wv.key_to_index and j in model.wv.key_to_index:
            # adding two words
            out.extend([('w1+w2',i,j,k,w,v) for k,(w,v) in enumerate(model.wv.most_similar(positive=[i, j])[:n_order])])

            # subtracted
            out.extend([('w1-w2',i,j,k,w,v) for k,(w,v) in enumerate(model.wv.most_similar(positive=[i], negative=[j])[:n_order])])
            out.extend([('w2-w1',i,j,k,w,v) for k,(w,v) in enumerate(model.wv.most_similar(positive=[j], negative=[i])[:n_order])])

    pd.DataFrame(out, columns=['Calculation', 'w1', 'w2', 'Position', 'Result Word', 'Similarity Score']).to_csv(DATAFOLDER + f'comparing_grouped_w2c.csv', index=False)



def cluster_top_words():
    model = gensim.models.Word2Vec.load(DATAFOLDER + f'Models/SM.word2vec')
    wordvec = np.array([model.wv[w] for w in TARGET_WORDS])

    # cluster them into two
    model = KMeans(2, n_init='auto')
    model.fit(wordvec)
    labels = model.predict(wordvec)

    # print(target_words)
    print(labels)


def OBSOLETE_cluster_top_words_centroids():
    for clusters in [
            [0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1],
            [0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1],
            [1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1]
        ]:

        words0 = [n for i,n in enumerate(TARGET_WORDS) if clusters[i] == 0]
        words1 = [n for i,n in enumerate(TARGET_WORDS) if clusters[i] == 1]

        
        model = gensim.models.Word2Vec.load(DATAFOLDER + f'Models/SM.word2vec')
        centroid0 = np.average([model.wv[w] for w in words0], axis=0)
        centroid1 = np.average([model.wv[w] for w in words1], axis=0)

        topword0 = model.wv.similar_by_vector(centroid0)
        topword1 = model.wv.similar_by_vector(centroid1)

        # for i,j in topword1:
        #     print(i,j)
        print(topword0)
        print(topword1)


def OBSOLETE_similar_to_given_docs():
    docs1 = ["SM (23)", "SM (24)"] # Lajos Egri
    docs2 = ["SM (41)", "SM (43)"] # Syd Field

    df = pd.read_csv(DATAFOLDER + f'w2v_docvectors.csv').sort_values(by=['id'])
    df = df.loc[df['id'].str.contains("SM")]
    df = df.set_index('id')


    df_doc1 = df.loc[df.index.isin(docs1)].copy().sum().to_frame().T
    df_doc1['id'] = "Lajos Ergi"
    df_doc1 = df_doc1.set_index('id')
    
    df_doc2 = df.loc[df.index.isin(docs2)].copy().sum().to_frame().T
    df_doc2['id'] = "Syd Field"
    df_doc2 = df_doc2.set_index('id')

    # df = df.append(pd.Series(df_doc1),ignore_index=True)
    # df = df.append(pd.Series(df_doc2),ignore_index=True)
    df = pd.concat([df, df_doc1, df_doc2])
    print(df.index)

    coss = cosine_similarity(df)

    print(coss.shape)

    pd.DataFrame(coss).to_csv(DATAFOLDER + f'./w2v_doc_similarity.csv', index=False)
