# -*- coding: utf-8 -*-
from utils import *
import gensim
import numpy as np
from collections import Counter
import pandas as pd


def for_tf():
    # Vectors needs to be in a shape of (len(vectors), len(items)) when fed into Dense2Corpus - this returns (len(items), len(items))
    similarity_threshold = 0.5
    df = pd.read_csv(DATAFOLDER + f'tf-idf.csv')
    embeddings = df.drop(['id'], axis=1).to_numpy()
    # Get similar words from each embeddings
    similarities = np.triu(
        np.array(
            gensim.similarities.MatrixSimilarity(
                gensim.matutils.Dense2Corpus(embeddings.T)))
    , 1)
    matches = similarities >= similarity_threshold
    # print(np.count_nonzero(matches))
    indices = np.argwhere(matches)
    out = []
    for i,j in indices:
        # add edge
        weight = similarities[i, j]
        out.append((i,j,weight))
            
    df = pd.DataFrame(out, columns=['source','target', 'weight'])
    
    df.to_csv(DATAFOLDER + 'tf-edge.csv', index=False)


def for_lda():
    # Vectors needs to be in a shape of (len(vectors), len(items)) when fed into Dense2Corpus - this returns (len(items), len(items))
    similarity_threshold = 0.5
    df = pd.read_csv(DATAFOLDER + f'lda_docvectors.csv')
    embeddings = df.drop(['id'], axis=1).to_numpy()
    # Get similar words from each embeddings
    similarities = np.triu(
        np.array(
            gensim.similarities.MatrixSimilarity(
                gensim.matutils.Dense2Corpus(embeddings.T)))
    , 1)
    matches = similarities >= similarity_threshold
    # print(np.count_nonzero(matches))
    indices = np.argwhere(matches)
    out = []
    for i,j in indices:
        # add edge
        weight = similarities[i, j]
        out.append((i,j,weight))
            
    df = pd.DataFrame(out, columns=['source','target', 'weight'])
    
    df.to_csv('C:/Users/Raphael_Studio/Dropbox/논문/Screenwriting/lda-edge.csv', index=False)
# for_lda()

def for_word2vec():
    similarity_threshold = 0.9 

    # nodes = set()
    edges = {}

    for f in [f for f in glob.glob(DATAFOLDER + f'Models/w2v/*.word2vec')]:
        id = os.path.splitext(os.path.basename(f))[0]
        
        with open(f, 'rb') as file:
            model = gensim.models.Word2Vec.load(f)

        # Get list of words per embedding
        words = model.wv.index_to_key
        # Get similar words from each embeddings
        similarities = np.triu(
            np.array(
                gensim.similarities.MatrixSimilarity(
                    gensim.matutils.Dense2Corpus(model.wv.vectors.T)))
        , 1)
        matches = similarities >= similarity_threshold
        # print(f, ",", np.count_nonzero(matches))

        # Get indices of matches words
        indices = np.argwhere(matches)

        for i,j in indices:
            # # add both words to nodes
            # nodes.add(words[i])
            # nodes.add(words[j])

            # add edge
            if (words[i], words[j]) in edges:
                weight, freq = edges[(words[i], words[j])]
                edges[(words[i], words[j])] = (weight + similarities[i,j], freq + 1)
            elif (words[j], words[i]) in edges:
                weight, freq = edges[(words[j], words[i])]
                edges[(words[j], words[i])] = (weight + similarities[j,i], freq + 1)
            else:
                edges[(words[i], words[j])] = (similarities[i,j], 1)
            
    # Count edges to get frequencies
    edgelist = [(i,j,k,l) for (i,j),(k,l) in edges.items()]
    df = pd.DataFrame(edgelist, columns=['source', 'target', 'weight', 'freq'])
    df.to_csv(DATAFOLDER + f'word2vec_edge_list_thres_{similarity_threshold}.csv', index=False)
# for_word2vec()