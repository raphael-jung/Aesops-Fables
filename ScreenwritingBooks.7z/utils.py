import glob
import os
import pickle
from sklearn.cluster import KMeans
from nltk.cluster import KMeansClusterer


# file locations
DATAFOLDER = 'E:/Dataset/ScreenwritingBooks/'
TARGET_WORDS = ["function", "structure", "character", "action", "dialogue", "conflict", "genre", "plot", "event", "theme", "time", "space", "setting", "background"]
    
paths_pdf = [f for f in glob.glob(DATAFOLDER+'Docs/*.pdf')]
paths_epub = [f for f in glob.glob(DATAFOLDER+'Docs/*.epub')]

paths_w2v = [f for f in glob.glob(DATAFOLDER+'Models/w2v/*.word2vec')]
    
def get_docs(foldername="Docs"):
    docs = []
    for f in [f for f in glob.glob(DATAFOLDER+f'{foldername}/*.pickle')]:
        with open(f, 'rb') as file:
            docs.append(pickle.load(file))
    return docs


def kmeans(embeddings,num_topics):
  model = KMeans(num_topics, n_init='auto')
  model.fit(embeddings)
  labels = model.predict(embeddings)
  return labels

