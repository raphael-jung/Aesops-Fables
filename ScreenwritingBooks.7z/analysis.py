import pandas as pd
import numpy as np
from utils import *

# Get top n words
df = pd.read_csv(DATAFOLDER + 'tf-idf.csv')
df = df.set_index('id')
out = []
print(df)

s = df.sum().nlargest(20, 'all')
print(s)
# top = row.nlargest(10, 'last')
# out.append([i] + top.index.tolist() + top.values.tolist())
# pd.DataFrame(out).to_csv(DATAFOLDER + 'top_tfidf.csv', index=False)
