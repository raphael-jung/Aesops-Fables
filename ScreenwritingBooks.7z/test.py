import pandas as pd

df = pd.read_excel(open('C:/Users/Raphael_Studio/Dropbox/논문/SE education/Dataset.xlsx', 'rb'), sheet_name='Curriculum')
df2 = df.drop(['P_ID','Type'], axis=1).drop_duplicates()
df3 = df.drop(['C_ID', 'Type', 'Code', 'Name'], axis=1)
df4 = df2.merge(df3, left_index=True, right_index=True)
df4.to_csv("test.csv",index=False)



